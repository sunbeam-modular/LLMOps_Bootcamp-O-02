# Observability and security

Langfuse records traces and spans for every LLM request, including token usage, cost, latency, prompt versions and
user feedback. Prometheus collects numeric metrics, and Grafana turns them into dashboards. Alerts fire on high
latency, error rates or unexpected cost.

Drift monitoring compares current behaviour, such as retrieval scores or answer length, with a baseline to detect
changes in data or quality. An audit trail records who asked what and which prompt version answered, without storing
sensitive raw text.

Prompt injection is an attack where input text tries to override the system instructions. The OWASP Top 10 for LLM
applications lists risks such as prompt injection, sensitive information disclosure and insecure output handling.
Guardrails validate inputs and outputs, for example blocking injection attempts and redacting personal data such as
email addresses. Secrets must never be placed in prompts, images or source control.
