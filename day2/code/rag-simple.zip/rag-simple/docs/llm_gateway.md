# LLM gateway and serving

An LLM gateway such as LiteLLM exposes one OpenAI-compatible API in front of many providers and local models.
It provides routing, retries, fallback to a backup model, caching, rate limits and per-key budgets with cost tracking.

Exact caching returns a stored answer for an identical request. Semantic caching also returns stored answers for
requests that are similar in meaning, which lowers cost and latency.

vLLM is a high-throughput inference engine. It uses continuous batching and PagedAttention to manage the KV cache
efficiently, and it exposes an OpenAI-compatible server. Quantization reduces model memory so larger models fit on
smaller GPUs, usually with a small quality trade-off.

KServe is a Kubernetes-native model serving platform. An InferenceService describes the model, its runtime and its
scaling, and KServe supports canary rollouts and scale-to-zero.
