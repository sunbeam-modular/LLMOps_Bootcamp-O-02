# Docker basics

A Docker image is a read-only template that contains an application and everything it needs to run.
Images are built from a Dockerfile, and each instruction that changes the filesystem creates a cached layer.

A container is a running instance of an image. It has its own thin writable layer, so files written inside a
container disappear when the container is removed. Persistent data must be stored in a volume.

Docker Compose defines and runs multi-container applications from a single YAML file. It handles networking,
service dependencies and health checks, so a whole stack can be started with one command: docker compose up.

Multi-stage builds use one stage to build dependencies and a small final stage to run the app. They reduce image
size and keep build tools out of production images. Trivy scans images for known vulnerabilities.
