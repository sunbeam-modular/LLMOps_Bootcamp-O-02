# Evaluating LLM applications

LLM applications need systematic evaluation because small changes to prompts, models or retrieval can silently
change answer quality. A golden dataset is a curated set of questions with expected answers or expected sources.

Retrieval metrics check whether the right documents were found, for example hit rate. Generation metrics check the
answer itself, for example faithfulness to the context, answer relevance and hallucination.

LLM-as-judge uses a model to score answers. It scales well but can be biased toward longer answers, so judges should
be calibrated against human labels.

A release gate sets pass or fail thresholds on evaluation scores. If scores drop below the threshold, the CI pipeline
blocks the merge or deployment. Regression tests re-run the golden dataset whenever a prompt, model or retriever changes.
