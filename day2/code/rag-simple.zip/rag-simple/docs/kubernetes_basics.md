# Kubernetes basics

Kubernetes runs containers across a cluster of nodes. The control plane decides where workloads run, and each
node runs a kubelet that starts the containers.

A Pod is the smallest deployable unit and holds one or more containers. A Deployment manages a ReplicaSet of Pods
and handles rolling updates and rollbacks. A Service gives Pods a stable network address, and an Ingress routes
external HTTP traffic to Services.

Configuration is kept in ConfigMaps, and sensitive values such as API keys are stored in Secrets. A liveness probe
restarts a stuck container, a readiness probe removes a Pod from traffic until it is ready, and a startup probe
protects slow-starting apps. Resource requests and limits control CPU and memory.

The Horizontal Pod Autoscaler adds or removes replicas based on metrics such as CPU. KEDA can scale on events and
external metrics, including down to zero. Stateful workloads such as Qdrant use StatefulSets with PersistentVolumes.
