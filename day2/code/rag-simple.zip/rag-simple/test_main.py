from fastapi.testclient import TestClient

from main import app

client = TestClient(app)


def test_health():
    r = client.get("/health")
    assert r.status_code == 200 and r.json()["chunks"] > 0


def test_chat_finds_the_right_document():
    r = client.post("/chat", json={"question": "What is a Docker image?"})
    assert r.status_code == 200
    assert "docker_basics.md" in r.json()["sources"]
