"""A deliberately small RAG service. One file, in-memory search, works with or without an API key.

  - Starts up: reads docs/*.md, splits them into paragraphs, turns each into a vector.
  - POST /chat: finds the 3 most similar paragraphs and answers from them.
  - With OPENAI_API_KEY set it uses a real model (set LLM_BASE_URL for any OpenAI-compatible server).
  - Without a key it uses a simple word-hash "embedding" and returns the matching text, so it still runs.
"""

import hashlib
import math
import os
import re
from pathlib import Path

from fastapi import FastAPI
from pydantic import BaseModel

DOCS_DIR = Path(os.getenv("DOCS_DIR", "docs"))
API_KEY = os.getenv("OPENAI_API_KEY", "")
LLM_MODEL = os.getenv("LLM_MODEL", "gpt-4o-mini")
EMBED_MODEL = os.getenv("EMBEDDING_MODEL", "text-embedding-3-small")
DIM = 256

client = None
if API_KEY:
    from openai import OpenAI

    client = OpenAI(api_key=API_KEY, base_url=os.getenv("LLM_BASE_URL") or None)


def embed(text: str) -> list[float]:
    """Turn text into a vector. Real model if we have a key, otherwise hash each word into a bucket."""
    if client:
        return client.embeddings.create(model=EMBED_MODEL, input=text).data[0].embedding
    vec = [0.0] * DIM
    for word in re.findall(r"[a-z0-9]+", text.lower()):
        vec[int(hashlib.md5(word.encode()).hexdigest(), 16) % DIM] += 1.0
    return vec


def cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    norm = math.sqrt(sum(x * x for x in a)) * math.sqrt(sum(y * y for y in b))
    return dot / norm if norm else 0.0


def load_chunks() -> list[dict]:
    """Each paragraph of each markdown file becomes one searchable chunk."""
    chunks = []
    for path in sorted(DOCS_DIR.glob("*.md")):
        for para in path.read_text().split("\n\n"):
            para = para.strip()
            if len(para) > 40:
                chunks.append({"source": path.name, "text": para, "vector": embed(para)})
    return chunks


app = FastAPI(title="Simple RAG")
CHUNKS = load_chunks()


class Question(BaseModel):
    question: str


@app.get("/health")
def health():
    return {"status": "ok", "chunks": len(CHUNKS), "mode": "openai" if client else "offline"}


@app.post("/chat")
def chat(body: Question):
    q_vec = embed(body.question)
    top = sorted(CHUNKS, key=lambda c: cosine(q_vec, c["vector"]), reverse=True)[:3]
    context = "\n\n".join(c["text"] for c in top)

    if client:
        prompt = f"Answer using only this context. If it is not there, say you don't know.\n\n{context}\n\nQuestion: {body.question}"
        reply = client.chat.completions.create(model=LLM_MODEL, messages=[{"role": "user", "content": prompt}])
        answer = reply.choices[0].message.content
    else:
        answer = "(offline mode) Most relevant text: " + top[0]["text"] if top else "No documents loaded."

    return {"answer": answer, "sources": sorted({c["source"] for c in top})}
