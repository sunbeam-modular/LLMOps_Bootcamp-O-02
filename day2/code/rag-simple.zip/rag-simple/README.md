# Simple RAG (starter for Day 2)

One file (`main.py`, about 80 lines), three dependencies, no database. It reads `docs/*.md`, finds the
paragraphs most similar to your question, and answers from them.

## Run it
    pip install -r requirements.txt
    uvicorn main:app --port 8000
    curl localhost:8000/health
    curl -X POST localhost:8000/chat -H 'content-type: application/json' -d '{"question":"What is a Docker image?"}'

No API key needed: without one it runs in offline mode and returns the best-matching text.
To use a real model: `export OPENAI_API_KEY=...` (and `LLM_BASE_URL` for any OpenAI-compatible server).

## Containerize it
    docker build -t simple-rag .
    docker run -p 8000:8000 simple-rag
    docker run -p 8000:8000 -e OPENAI_API_KEY=... simple-rag     # real model

## Test
    pip install pytest httpx && pytest -q

## What it leaves out (the full course app adds these)
Qdrant vector database, guardrails, versioned prompts, metrics, auth and an evaluation gate.
